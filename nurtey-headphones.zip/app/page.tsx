import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Headphones, Truck, Shield, Award } from "lucide-react"

export default function HomePage() {
  const featuredProducts = [
    {
      id: 1,
      name: "Nurtey Pro Max",
      price: "$299",
      originalPrice: "$399",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 124,
      badge: "Best Seller",
    },
    {
      id: 2,
      name: "Nurtey Wireless Elite",
      price: "$199",
      originalPrice: "$249",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.6,
      reviews: 89,
      badge: "New",
    },
    {
      id: 3,
      name: "Nurtey Studio",
      price: "$399",
      originalPrice: "$499",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 156,
      badge: "Premium",
    },
  ]

  const features = [
    {
      icon: <Headphones className="h-8 w-8" />,
      title: "Premium Sound Quality",
      description: "Experience crystal-clear audio with our advanced driver technology",
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: "Free Shipping",
      description: "Free worldwide shipping on all orders over $100",
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "2-Year Warranty",
      description: "Comprehensive warranty coverage for peace of mind",
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: "Award Winning",
      description: "Recognized by industry experts for innovation and quality",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
        <div className="container mx-auto px-4 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="bg-purple-600/20 text-purple-200 border-purple-500/30">
                  Premium Audio Experience
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                  Elevate Your
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                    {" "}
                    Sound Experience
                  </span>
                </h1>
                <p className="text-xl text-gray-300 leading-relaxed">
                  Discover the perfect blend of premium quality, cutting-edge technology, and exceptional comfort with
                  Nurtey headphones.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white px-8">
                  Shop Now
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
                >
                  Learn More
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="relative z-10">
                <img
                  src="/placeholder.svg?height=500&width=500"
                  alt="Nurtey Premium Headphones"
                  className="w-full max-w-md mx-auto"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 blur-3xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose Nurtey?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We're committed to delivering exceptional audio experiences through innovation, quality, and customer
              satisfaction.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center p-6 border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="space-y-4">
                  <div className="text-purple-600 flex justify-center">{feature.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Lifestyle Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">Perfect for Every Lifestyle</h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                Whether you're working from home, hitting the gym, or traveling the world, Nurtey headphones adapt to
                your lifestyle with superior comfort and performance.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Person working with headphones"
                  className="rounded-lg shadow-lg"
                />
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Person exercising with headphones"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholder.svg?height=600&width=500"
                alt="Lifestyle with Nurtey headphones"
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32">
                <img
                  src="/placeholder.svg?height=128&width=128"
                  alt="Nurtey logo badge"
                  className="rounded-full shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Featured Products</h2>
            <p className="text-xl text-gray-600">
              Discover our most popular headphones, loved by audiophiles worldwide
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-4 left-4 bg-purple-600">{product.badge}</Badge>
                </div>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.name}</h3>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">({product.reviews} reviews)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-purple-600">{product.price}</span>
                      <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
                    </div>
                  </div>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">Add to Cart</Button>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className="border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white bg-transparent"
            >
              View All Products
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold">Crafting Audio Excellence Since 2018</h2>
              <p className="text-xl text-gray-300 leading-relaxed">
                At Nurtey, we believe that great sound should be accessible to everyone. Our team of audio engineers and
                designers work tirelessly to create headphones that deliver exceptional performance without compromising
                on comfort or style.
              </p>
              <p className="text-lg text-gray-400">
                From our state-of-the-art manufacturing facilities to our rigorous quality testing, every Nurtey product
                is built to exceed your expectations and provide years of listening pleasure.
              </p>
              <div className="grid grid-cols-3 gap-4">
                <img src="/placeholder.svg?height=100&width=150" alt="Manufacturing process" className="rounded-lg" />
                <img src="/placeholder.svg?height=100&width=150" alt="Quality testing" className="rounded-lg" />
                <img src="/placeholder.svg?height=100&width=150" alt="Design process" className="rounded-lg" />
              </div>
              <Button
                variant="outline"
                className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
              >
                Learn Our Story
              </Button>
            </div>
            <div className="relative">
              <img
                src="/placeholder.svg?height=400&width=600"
                alt="Nurtey Manufacturing"
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -top-6 -left-6">
                <img
                  src="/placeholder.svg?height=150&width=200"
                  alt="Award certificate"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-4xl font-bold">Ready to Experience Premium Sound?</h2>
            <p className="text-xl opacity-90">
              Join thousands of satisfied customers who have made Nurtey their choice for premium audio experiences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="bg-white text-purple-600 hover:bg-gray-100">
                Shop Collection
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
              >
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
