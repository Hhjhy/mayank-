import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, Filter } from "lucide-react"

export default function ProductsPage() {
  const products = [
    {
      id: 1,
      name: "Nurtey Pro Max",
      price: "$299",
      originalPrice: "$399",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 124,
      badge: "Best Seller",
      category: "Wireless",
    },
    {
      id: 2,
      name: "Nurtey Wireless Elite",
      price: "$199",
      originalPrice: "$249",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.6,
      reviews: 89,
      badge: "New",
      category: "Wireless",
    },
    {
      id: 3,
      name: "Nurtey Studio",
      price: "$399",
      originalPrice: "$499",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 156,
      badge: "Premium",
      category: "Wired",
    },
    {
      id: 4,
      name: "Nurtey Gaming Pro",
      price: "$249",
      originalPrice: "$299",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.7,
      reviews: 203,
      badge: "Gaming",
      category: "Gaming",
    },
    {
      id: 5,
      name: "Nurtey Classic",
      price: "$149",
      originalPrice: "$199",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.5,
      reviews: 67,
      badge: "Value",
      category: "Wired",
    },
    {
      id: 6,
      name: "Nurtey Sport",
      price: "$179",
      originalPrice: "$229",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.4,
      reviews: 91,
      badge: "Sport",
      category: "Wireless",
    },
    {
      id: 7,
      name: "Nurtey Kids Safe",
      price: "$99",
      originalPrice: "$129",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.6,
      reviews: 45,
      badge: "Kids",
      category: "Wireless",
    },
    {
      id: 8,
      name: "Nurtey Travel Companion",
      price: "$159",
      originalPrice: "$199",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.5,
      reviews: 78,
      badge: "Travel",
      category: "Wireless",
    },
    {
      id: 9,
      name: "Nurtey Audiophile Edition",
      price: "$599",
      originalPrice: "$699",
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 234,
      badge: "Audiophile",
      category: "Wired",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="relative mb-8 rounded-lg overflow-hidden">
            <img
              src="/placeholder.svg?height=300&width=1200"
              alt="Nurtey Product Collection"
              className="w-full h-48 lg:h-64 object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <div className="text-center text-white">
                <h1 className="text-3xl lg:text-4xl font-bold mb-4">Our Products</h1>
                <p className="text-xl">Discover our complete range of premium headphones and audio equipment</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Select>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="wireless">Wireless</SelectItem>
              <SelectItem value="wired">Wired</SelectItem>
              <SelectItem value="gaming">Gaming</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Price Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Prices</SelectItem>
              <SelectItem value="under-200">Under $200</SelectItem>
              <SelectItem value="200-300">$200 - $300</SelectItem>
              <SelectItem value="over-300">Over $300</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" className="sm:w-auto bg-transparent">
            <Filter className="h-4 w-4 mr-2" />
            More Filters
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Badge className="absolute top-4 left-4 bg-purple-600">{product.badge}</Badge>
              </div>
              <CardContent className="p-6 space-y-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <p className="text-sm text-gray-500 mb-3">{product.category}</p>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">({product.reviews} reviews)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold text-purple-600">{product.price}</span>
                    <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1 bg-purple-600 hover:bg-purple-700">Add to Cart</Button>
                  <Button variant="outline" className="px-4 bg-transparent">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button
            variant="outline"
            size="lg"
            className="border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white bg-transparent"
          >
            Load More Products
          </Button>
        </div>
      </div>
    </div>
  )
}
