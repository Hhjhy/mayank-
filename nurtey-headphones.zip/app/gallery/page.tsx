import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function GalleryPage() {
  const galleryCategories = [
    {
      title: "Product Showcase",
      images: [
        { src: "/placeholder.svg?height=400&width=600", alt: "Nurtey Pro Max in studio", category: "products" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Wireless Elite lifestyle", category: "products" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Gaming Pro setup", category: "products" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Studio headphones detail", category: "products" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Sport headphones action", category: "products" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Kids Safe colorful design", category: "products" },
      ],
    },
    {
      title: "Behind the Scenes",
      images: [
        { src: "/placeholder.svg?height=400&width=600", alt: "Design team brainstorming", category: "behind-scenes" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Manufacturing process", category: "behind-scenes" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Quality testing lab", category: "behind-scenes" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Acoustic chamber testing", category: "behind-scenes" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Prototype development", category: "behind-scenes" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Team collaboration", category: "behind-scenes" },
      ],
    },
    {
      title: "Lifestyle & Usage",
      images: [
        { src: "/placeholder.svg?height=400&width=600", alt: "Professional using headphones", category: "lifestyle" },
        {
          src: "/placeholder.svg?height=400&width=600",
          alt: "Commuter with wireless headphones",
          category: "lifestyle",
        },
        { src: "/placeholder.svg?height=400&width=600", alt: "Gamer in action", category: "lifestyle" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Fitness enthusiast", category: "lifestyle" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Music producer in studio", category: "lifestyle" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Student studying", category: "lifestyle" },
      ],
    },
    {
      title: "Awards & Recognition",
      images: [
        { src: "/placeholder.svg?height=400&width=600", alt: "CES Innovation Award", category: "awards" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Design Excellence Certificate", category: "awards" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Customer Choice Award", category: "awards" },
        { src: "/placeholder.svg?height=400&width=600", alt: "Tech Innovation Prize", category: "awards" },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Gallery</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our world through images - from product designs to behind-the-scenes moments and customer
            experiences.
          </p>
        </div>

        {/* Gallery Categories */}
        {galleryCategories.map((category, categoryIndex) => (
          <div key={categoryIndex} className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl lg:text-3xl font-bold text-gray-900">{category.title}</h2>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                {category.images.length} images
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {category.images.map((image, imageIndex) => (
                <Card key={imageIndex} className="group overflow-hidden hover:shadow-xl transition-all duration-300">
                  <div className="relative">
                    <img
                      src={image.src || "/placeholder.svg"}
                      alt={image.alt}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300"></div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-700 font-medium">{image.alt}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}

        {/* CTA Section */}
        <div className="text-center mt-16 p-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white">
          <h2 className="text-2xl lg:text-3xl font-bold mb-4">Share Your Nurtey Experience</h2>
          <p className="text-lg opacity-90 mb-6">
            Tag us @nurtey on social media to be featured in our customer gallery
          </p>
          <Button variant="secondary" className="bg-white text-purple-600 hover:bg-gray-100">
            Follow Us
          </Button>
        </div>
      </div>
    </div>
  )
}
