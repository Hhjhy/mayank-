import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Award, Globe, Heart } from "lucide-react"

export default function AboutPage() {
  const stats = [
    { number: "50K+", label: "Happy Customers" },
    { number: "15+", label: "Awards Won" },
    { number: "25+", label: "Countries Served" },
    { number: "6", label: "Years of Excellence" },
  ]

  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Audio engineer with 15+ years of experience in premium sound design.",
    },
    {
      name: "Michael Chen",
      role: "Head of Design",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Industrial designer passionate about creating beautiful, functional products.",
    },
    {
      name: "Emily Rodriguez",
      role: "Chief Technology Officer",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Tech innovator focused on advancing audio technology and user experience.",
    },
    {
      name: "David Kim",
      role: "Head of Engineering",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Mechanical engineer specializing in acoustic design and product development.",
    },
    {
      name: "Lisa Thompson",
      role: "Marketing Director",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Brand strategist with expertise in building authentic connections with customers.",
    },
    {
      name: "James Wilson",
      role: "Quality Assurance Lead",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Quality expert ensuring every product meets our rigorous standards.",
    },
  ]

  const values = [
    {
      icon: <Award className="h-8 w-8" />,
      title: "Quality First",
      description:
        "We never compromise on quality. Every product undergoes rigorous testing to ensure it meets our high standards.",
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Customer Focused",
      description:
        "Our customers are at the heart of everything we do. We listen, learn, and continuously improve based on feedback.",
    },
    {
      icon: <Globe className="h-8 w-8" />,
      title: "Global Impact",
      description:
        "We're committed to making premium audio accessible worldwide while maintaining sustainable practices.",
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Passion Driven",
      description:
        "Our love for music and audio excellence drives us to create products that enhance every listening experience.",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-900 via-slate-900 to-purple-900 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <Badge variant="secondary" className="bg-purple-600/20 text-purple-200 border-purple-500/30">
              Our Story
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold">
              Crafting Audio Excellence
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                {" "}
                Since 2018
              </span>
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
              Born from a passion for exceptional sound quality, Nurtey has grown from a small startup to a globally
              recognized brand, dedicated to delivering premium audio experiences that inspire and delight.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-purple-600 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">Our Journey</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                It all started in a small garage in 2018, where our founder Sarah Johnson, an audio engineer with a
                dream, began experimenting with headphone designs that would revolutionize the listening experience.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                What began as a quest for the perfect sound has evolved into a mission to make premium audio accessible
                to music lovers worldwide. Today, Nurtey products are trusted by audiophiles, professionals, and
                everyday listeners in over 25 countries.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Our commitment to innovation, quality, and customer satisfaction has earned us numerous awards and, more
                importantly, the loyalty of thousands of satisfied customers who trust Nurtey for their audio needs.
              </p>
              <div className="grid grid-cols-2 gap-4 mt-6">
                <img
                  src="/placeholder.svg?height=150&width=200"
                  alt="Early prototype"
                  className="rounded-lg shadow-md"
                />
                <img src="/placeholder.svg?height=150&width=200" alt="First office" className="rounded-lg shadow-md" />
              </div>
            </div>
            <div className="space-y-4">
              <img src="/placeholder.svg?height=300&width=500" alt="Nurtey Journey" className="rounded-lg shadow-2xl" />
              <div className="grid grid-cols-2 gap-4">
                <img
                  src="/placeholder.svg?height=150&width=240"
                  alt="Modern facility"
                  className="rounded-lg shadow-md"
                />
                <img
                  src="/placeholder.svg?height=150&width=240"
                  alt="Team collaboration"
                  className="rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              These core principles guide everything we do and shape the way we create products and serve our customers.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center p-6 border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="space-y-4">
                  <div className="text-purple-600 flex justify-center">{value.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">The passionate individuals behind Nurtey's success</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-64 object-cover"
                  />
                </div>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{member.name}</h3>
                    <p className="text-purple-600 font-medium">{member.role}</p>
                  </div>
                  <p className="text-gray-600">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Behind the Scenes</h2>
            <p className="text-xl text-gray-600">A glimpse into our design process and company culture</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Design workshop"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Testing lab"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Team meeting"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Product assembly"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Quality control"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Office culture"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Innovation lab"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
            <img
              src="/placeholder.svg?height=250&width=300"
              alt="Customer feedback session"
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-4xl font-bold">Join the Nurtey Family</h2>
            <p className="text-xl opacity-90">
              Experience the difference that passion, quality, and innovation can make in your audio journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="bg-white text-purple-600 hover:bg-gray-100">
                Shop Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
              >
                Contact Us
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
